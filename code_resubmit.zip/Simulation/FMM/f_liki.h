#ifndef _F_LIKI_H
#define _F_LIKI_H

#include "f_mmult.h" 
#include "f_integral.h"

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector f_liki(NumericVector OT_label, NumericVector B, NumericVector J, NumericVector Fail_label, NumericVector z, NumericVector OT, NumericVector DELTA, NumericVector Queue, NumericVector y, NumericVector NT, double pi, int K, int N, int M, int NY, int SNT, int NZ, NumericVector lambda, NumericVector beta, NumericVector c, NumericVector b, NumericVector psi_eps, int NP, int IF_QUADRATIC, NumericVector kns, NumericVector xi) {
  
  NumericMatrix beta1(1,NZ);
  for(int r=0; r<NZ; ++r){
    beta1(0,r) = beta[r];
  }
  NumericVector liki(M*N);
  
  for (int i = 0; i < N; ++i){
    for (int m = 0; m < M; ++m){
      double dic_1 = 0;
      double dic_2 = 0;
      double dic_3 = 0;
      double dic_4 = 0;
      double dic_5 = 0;
      for(int k=0; k<NY; ++k){
        int t_temp = NT[i];
        //Rprintf("i:%d; m:%d; k:%d; \n", (i+1), (m+1), (k+1));
        // --------------- MMM ------------------------
        for(int j=0; j<t_temp; ++j){
          double Y_n = y[Queue[i]+j+k*SNT];
          for (int p = 0; p < NP; ++p){
            Y_n -= b[m*NY*NP+k*NP+p]*B[p*SNT+Queue[i]+j];
          }
          //Rprintf("j:%d; Y_n=%f;    ",j, Y_n);
          dic_1 -= pow(Y_n,2)/(2*psi_eps[k]);
          dic_1 -= 0.5* log(2*pi*psi_eps[k]);
        }
        //Rprintf("\n");
      }
      
      // -------------- COX --------------------------
      int L = J.size()-1;
      for(int j=0; j<L; ++j){
        if((Fail_label[i]==(j+1))&(DELTA[i]==1)){
          dic_2 += log(lambda[j]);
        }
      }
      // -------------- 3 ----------------------------
      NumericMatrix z1(NZ,1);
      for(int k=0; k<NZ; ++k){
        z1(k,0) = z[k*N+i];
      }
      dic_3 = DELTA[i] * f_mmult(beta1,z1)(0,0);
      // -------------- 4 ----------------------------
      NumericVector u1(NP);
      for(int p=0; p<NP; ++p){
        for(int k=0; k<NY; ++k){
          u1[p] += c[k] * b[m*NY*NP+k*NP+p];
        }
        //Rprintf("p:%d; u1=%f;  ",(p+1), u1[p]);
        dic_4 += DELTA[i]*B[p*SNT+Queue[i]+OT_label[i]]*u1[p];
      }
      dic_5 = exp(f_mmult(beta1,z1)(0,0))*f_integral(u1, J, lambda, Fail_label[i], K, OT[i], 1, 0, Fail_label[i], NP, IF_QUADRATIC, kns);
      //Rprintf("betaz: %f; integral: %f;\n", f_mmult(beta1,z1)(0,0), f_integral(u1, J, lambda, Fail_label[i], K, OT[i], 1, 0, Fail_label[i], NP, IF_QUADRATIC, kns));
      liki[m*N+i] = dic_1 + dic_2 + dic_3 + dic_4 + dic_5;
      //Rprintf("i:%d; m:%d; dic_1=%f,dic_2=%f,dic_3=%f,dic_4=%f,dic_5=%f\n", (i+1), (m+1), dic_1, dic_2, dic_3, dic_4, dic_5);
    }
    //Rprintf("i:%d; liki1=%f,liki2=%f,liki3=%f\n", (i+1), liki[i], liki[i+1*N], liki[i+2*N]);
  }
  
  return liki;
  
}

#endif
