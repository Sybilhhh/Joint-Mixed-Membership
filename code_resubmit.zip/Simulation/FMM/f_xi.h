#ifndef _F_XI_H
#define _F_XI_H
#include "f_dirichlet.h"

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector f_xi(NumericVector xi, NumericVector g, double a0, int N, int M) {
  NumericVector a(M);
  NumericVector xi_out = xi;
  for(int m=0; m<M; ++m){
    a[m] = a0;
    for(int i=0; i<N; ++i){
      a[m] += g[m*N+i];
    }
  }
  //Rprintf("a1 = %f, a2 = %f, a3 = %f\n", a[0], a[1], a[2]);
  xi_out = f_dirichlet(a,M);
  
  return xi_out;
}
#endif
