#ifndef _F_RI_H
#define _F_RI_H

#include "f_containNAN.h"

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector f_ri(NumericVector liki,int N, int M, NumericVector xi){
  NumericVector g_out(M*N);
  NumericVector samp(M);

  for(int m=0; m<M; ++m){
    samp[m] = m;
  }
  
  for(int i=0; i<N; ++i){
    NumericVector prob(M);
    for (int m = 0; m < M; ++m){
      prob[m] = xi[m] * exp(liki[m*N+i]);
    }
    
    double psum = sum(prob);
    for(int m=0; m<M; ++m){
      prob[m] = prob[m]/psum;
    }
    //Rprintf("i: %d; prob1: %f; prob2: %f; prob3: %f;\n",(i+1), prob[0], prob[1], prob[2]);
    double max = Rcpp::max(prob);
    //Rprintf("max: %f\n", max);
    bool s = containsNaN(prob);
    if(max< 1/M || max >1 || s){
      for(int m=0; m<M; ++m){
        prob[m] = 1.0/M;
        //Rprintf("k: %d; i: %d; prob1: %f;",(k+1),(i+1), prob[m]);
      }
    }
    //Rprintf("i: %d; prob1: %f; prob2: %f; prob3: %f;\n",(i+1), prob[0], prob[1], prob[2]);
    int label = Rcpp::sample(samp, 1, false, prob)[0];
    g_out[label*N+i] = 1.0;
  }
  return g_out;
}
#endif
