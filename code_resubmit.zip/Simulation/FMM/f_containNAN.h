#ifndef _F_CONTAINNAN_H
#define _F_CONTAINNAN_H

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
bool containsNaN(NumericVector A) {
  for (int i = 0; i < A.size(); i++) {
    if(NumericVector::is_na(A[i])){
      return true;  // A contains NaN
    }else if(Rcpp::traits::is_infinite<REALSXP>(A[i])){
      return true;  // A contains NaN
    }else if (Rcpp::traits::is_infinite<REALSXP>(A[i])) {
      return true;  // A contains NaN
    }
  }
  return false;  // A does not contain NaN
}

#endif

