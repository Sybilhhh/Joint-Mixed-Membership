library("mvtnorm")
library("numDeriv")
library("Rcpp")
library("RcppArmadillo")
library("RcppEigen")
library("LaplacesDemon")

sourceCpp("mcmc.cpp")

observed_data = readRDS("observed_data.RData")
N = 605
M = 3 # number of extreme profile
NY= 2 # dimension of y
NZ= 5 # number of covariates
NP = 6
J_len = 11
M_mcmc = 3
K = 10
####################################### Simulation setting and control ###################################################
REP= 1    ## number of replication
TT=10000    ## number of iteration of mcmc
S= 5000  ## T-S is the number of burn-in iteration
IF_AIC = 1
IF_QUADRATIC = 0
IF_MMM = 1
IF_COX = 1
switching_label = c(0,0) # constraint switching label in label switching c++, first entry k; second entry p

#----------------- Save data ----------------------#
#---------- Mixed Membership model---------------#
b_mcmc = array(0, dim = c(REP,TT,NY*NP,M))
g_mcmc = array(0,dim=c(REP,TT,N,M))
delta_0_mcmc = array(0,dim = c(REP,TT))
xi_mcmc = array(0, dim = c(REP,TT,M))
psi_epsmcmc = array(0,dim=c(REP,TT,NY))

b_rep = array(0,dim = c(REP,NY*NP,M))
g_rep = array(0,dim = c(REP,N,M))
delta_0_rep = rep(0,REP)
xi_rep = array(0,dim = c(REP,M))
psi_epsrep = array(0,dim=c(REP,NY))

b_sd = array(0,dim = c(REP,NY*NP,M))
g_sd = array(0,dim = c(REP,N,M))
delta_0_sd = rep(0,REP)
xi_sd = array(0,dim = c(REP,M))
psi_eps_sd = array(0,dim=c(REP,NY))

#----------------- Cox model ---------------------#
c_mcmc = array(0,dim = c(REP,TT,NY))
beta_mcmc = array(0,dim=c(REP,TT,NZ))
lambda_mcmc = array(0,dim=c(REP,TT,J_len-1))

c_rep = array(0,dim=c(REP,NY))
beta_rep = array(0,dim=c(REP,NZ))
lambda_rep = array(0,dim=c(REP,J_len-1))

c_sd = array(0,dim=c(REP,NY))
beta_sd = array(0,dim=c(REP,NZ))
lambda_sd = array(0,dim=c(REP,J_len-1))

AIC = rep(0,REP)

c_beta = 5.5
c_c = 0.2
c_delta = 0.08
c_b = 10
c_g = 0.05

mh = list()
mh[[1]] = c_beta
mh[[2]] = c_c
mh[[3]] = c_delta
mh[[4]] = c_b
mh[[5]] = c_g

#######################################################################################################################
# MCMC
start_time = Sys.time()
for(iter in 1:REP){
  num_list = 11
  ####### initial value #######
  #---------- Cox --------------------#
  lambda_cpp = rep(1,J_len-1)
  c_cpp = rep(0.5,NY)
  beta_cpp = rep(0,NZ)
  
  # --------------- MMM ---------------#
  b_cpp =as.numeric(matrix(rep(-seq(1,M_mcmc),NP*NY), nrow = NP*NY, ncol = M, byrow = T))
  psi_epscpp = rep(0.1,NY)
  delta_0_cpp = 0.8
  xi_cpp = rep(1,M_mcmc)/M_mcmc
  g_cpp = as.numeric(rdirichlet(N,delta_0_cpp*xi_cpp))
  
  ####### prior distribution ########
  #---------- Cox --------------------#
  # lambda
  alpha1 = 2
  alpha2 = 0.01
  # beta
  beta0 = rep(0,NZ)
  Sigma_beta0 = diag(NZ)
  # c
  c0 = 0
  sigma_c0 = 1
  # --------------- MMM ---------------#
  # b
  b0 = rep(0,NP)
  Sigma_b0 = diag(NP)*100
  # delta
  a0_delta = 1.2
  b0_delta = 5
  # g
  d0 = 1
  # psi_eps
  alpha_eps0 = 9
  beta_eps0 = 4
  
  prior = list()
  # Cox
  prior[[1]] = alpha1
  prior[[2]] = alpha2
  prior[[3]] = beta0
  prior[[4]] = Sigma_beta0
  prior[[5]] = c0
  prior[[6]] = sigma_c0
  # MMM
  prior[[7]] = b0
  prior[[8]] = Sigma_b0
  prior[[9]] = a0_delta
  prior[[10]] = b0_delta
  prior[[11]] = d0
  prior[[12]] = alpha_eps0
  prior[[13]] = beta_eps0
  
  
  para = list()
  # Cox
  para[[1]] = lambda_cpp
  para[[2]] = beta_cpp
  para[[3]] = c_cpp
  # MMM
  para[[4]] = b_cpp
  para[[5]] = g_cpp
  para[[6]] = psi_epscpp
  para[[7]] = delta_0_cpp
  para[[8]] = xi_cpp
  
  result = mcmc(observed_data[((iter-1)*num_list+1):((iter-1)*num_list+11)], para, mh, prior, K, iter, REP, TT, S, pi, IF_MMM, IF_COX, IF_AIC, IF_QUADRATIC, switching_label)
  if(iter == 1){
    save.image(file = "2K3M_NP61.RData")
  }
  if(iter == 2){
    save.image(file = "2K3M_NP62.RData")
  }
  if(iter == 3){
    save.image(file = "2K3M_NP63.RData")
  }
  if(iter == 4){
    save.image(file = "2K3M_NP64.RData")
  }
  if(iter == 5){
    save.image(file = "2K3M_NP65.RData")
  }
  
  AIC[iter] = mean(result$AIC)
  
  for(i in 1:TT){
    b_mcmc[iter,i,,] = matrix(result$b_str[((i-1)*M*NP*NY+1):(i*M*NP*NY)],nrow=NP*NY,byrow=F)
    g_mcmc[iter,i,,] = matrix(result$g_str[((i-1)*N*M+1):(i*N*M)],nrow=N,byrow=F)
  }
  delta_0_mcmc[iter,] = result$delta_0_str
  xi_mcmc[iter,,] = matrix(result$xi_str,ncol=M,byrow=T)
  psi_epsmcmc[iter,,] = matrix(result$psieps_str,nrow=TT,byrow=T) 
  
  # Cox
  c_mcmc[iter,,] = matrix(result$c_str,nrow=TT,byrow=T) 
  beta_mcmc[iter,,] = matrix(result$beta_str,nrow=TT,byrow=T) 
  lambda_mcmc[iter,,] = matrix(result$lambda_str,nrow=TT,byrow=T) 
  
  b_rep[iter,,] = apply(b_mcmc[iter,S:TT,,],2:3,mean)
  g_rep[iter,,] = apply(g_mcmc[iter,S:TT,,],2:3,mean)
  xi_rep[iter,] = apply(xi_mcmc[iter,S:TT,],2,mean)
  delta_0_rep[iter] = mean(delta_0_mcmc[iter,S:TT])
  psi_epsrep[iter,] = apply(psi_epsmcmc[iter,S:TT,],2,mean)
  
  c_rep[iter,] = apply(c_mcmc[iter,S:TT,],2,mean)
  beta_rep[iter,] = apply(beta_mcmc[iter,S:TT,],2,mean)
  lambda_rep[iter,] = apply(lambda_mcmc[iter,S:TT,],2,mean)
  
  b_sd[iter,,] = apply(b_mcmc[iter,S:TT,,],2:3,sd)
  g_sd[iter,,] = apply(g_mcmc[iter,S:TT,,],2:3,sd)
  xi_sd[iter,] = apply(xi_mcmc[iter,S:TT,],2,sd)
  delta_0_sd[iter] = sd(delta_0_mcmc[iter,S:TT])
  psi_eps_sd[iter,] = apply(psi_epsmcmc[iter,S:TT,],2,sd)
  
  c_sd[iter,] = apply(c_mcmc[iter,S:TT,],2,sd)
  beta_sd[iter,] = apply(beta_mcmc[iter,S:TT,],2,sd)
  lambda_sd[iter,] = apply(lambda_mcmc[iter,S:TT,],2,sd)
}

Iter_time = Sys.time() - start_time
sprintf("Need %.3f mins to iter %d replication", Iter_time, REP)


E_c = apply(c_rep,2,mean)
E_beta = apply(beta_rep,2,mean)
E_lambda = apply(lambda_rep,2,mean)
E_b = apply(b_rep,2:3,mean)
#E_delta_0 = apply(delta_0_rep,2,mean)
E_delta_0 = mean(delta_0_rep)
E_xi = apply(xi_rep,2,mean)
E_psi_eps = apply(psi_epsrep,2,mean)

sd_c = apply(c_sd,2,mean)
sd_beta = apply(beta_sd,2,mean)
sd_lambda = apply(lambda_sd,2,mean)
sd_b = apply(b_sd,2:3,mean)
#sd_delta_0 = apply(delta_0_sd,2,mean)
sd_delta_0 = mean(delta_0_sd)
sd_xi = apply(xi_sd,2,mean)
sd_psi_eps = apply(psi_eps_sd,2,mean)


z_c = E_c / sd_c
z_beta = E_beta/sd_beta
z_lambda = E_lambda/sd_lambda
#z_b = E_b/sd_b
z_delta_0 = E_delta_0/sd_delta_0
z_xi = E_xi/sd_xi
z_psi_eps = E_psi_eps/sd_psi_eps

print(z_c)
print(z_beta)
print(z_lambda)
#print(z_b)
print(z_delta_0)
print(z_xi)
print(z_psi_eps)

print(E_c)
print(E_beta)
print(E_lambda)
print(E_b)
print(E_delta_0)
print(E_xi)
print(E_psi_eps)

print(sd_c)
print(sd_beta)
print(sd_lambda)
print(sd_b)
print(sd_delta_0)
print(sd_xi)
print(sd_psi_eps)


result$at_beta/TT
result$at_c/TT
result$at_delta/TT
result$at_b/TT
mean(result$at_g/TT)

AIC


write.table(c_rep,"c_rep.txt")
write.table(beta_rep,"beta_rep.txt")
write.table(lambda_rep,"lambda_rep.txt")
write.table(b_rep,"b_rep.txt")
write.table(delta_0_rep,"delta_0_rep.txt")
write.table(xi_rep,"xi_rep.txt")
write.table(psi_epsrep,"psi_epsrep.txt")
write.table(g_rep,"g_rep.txt")


save.image(file = "2K3M_NP6.RData")
