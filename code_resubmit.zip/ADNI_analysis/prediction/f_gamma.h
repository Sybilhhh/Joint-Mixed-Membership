#ifndef _F_GAMMA_H
#define _F_GAMMA_H

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]

NumericVector f_gamma(NumericVector a){
  int n = a.length();
  NumericVector res(n);
  for(int i = 0; i<n; ++i){
    res[i] = ::tgamma(a[i]);
  }
  return res;
}
#endif
