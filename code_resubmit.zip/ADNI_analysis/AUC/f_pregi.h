#ifndef _F_PREGI_H
#define _F_PREGI_H

#include "f_mmult.h"
#include "f_dirichlet.h"
#include "f_integral.h"

#include <Rcpp.h> 
using namespace Rcpp;

// [[Rcpp::export]]
List f_pregi(NumericVector cgb, double delta_0, NumericVector xi, NumericVector gb, NumericVector b, NumericVector y, NumericVector B, NumericVector g, NumericVector psi_eps, NumericVector OT, NumericVector DELTA, NumericVector Fail_label, NumericVector J, NumericVector lambda, NumericVector beta, NumericVector z, NumericVector Queue, NumericVector c, NumericVector NT, int N, int M, int NY, int K, int NZ, int SNT, double d0, double c_g, NumericVector at_g, int NP, int IF_QUADRATIC, NumericVector kns, NumericVector OT_label, NumericMatrix Fail_label_tdelta, NumericVector t_test, NumericVector delta, NumericVector B_tdelta, int loop1, int loop2){
  NumericVector g_out = g;
  NumericMatrix bB(M,1);
  NumericMatrix g1(1,M);
  NumericMatrix gi_star(1,M);
  NumericMatrix beta1(1,NZ);
  NumericVector delta2(M);
  NumericMatrix delta1(M,1);
  NumericMatrix gi_diff(1,M);
  NumericMatrix z1(NZ,1);
  
  for(int m=0; m<M; ++m){
    delta2[m] = c_g * d0;
    delta1(m,0) = delta_0 * xi[m] - 1;
  }
  for(int i=0; i<NZ; ++i){
    beta1(0,i) = beta[i];
  }
  
  double t_temp1 = t_test[loop1];

  const int t_length = t_test.size();
  const int delta_length = delta.size();

  for(int i=0; i<N; ++i){
    if(!((OT[i]<=t_temp1)&(DELTA[i]==1))){
      for(int k=0; k<NZ; ++k){
        z1(k,0) = z[k*N+i];
      }

      //------------------------------ sample ------------------------------------//
      NumericVector g_star = f_dirichlet(delta2,M);
      
      //------------------------------ ratio 1------------------------------------//
      for(int j=0; j<M; ++j){
        if(g_star[j] == 0){
          g_star[j] = 1e-323;
        }
        if(g[j*N+i] == 0){
          g[j*N+i] = 1e-323;
        }
        g1(0,j) = g[j*N+i];
        gi_star(0,j) = g_star[j];
        gi_diff(0,j) = log(gi_star[j]) - log(g[j*N+i]);
      }
      double ratio_1 = f_mmult(gi_diff,delta1)(0,0);
      //------------------------------ ratio 2-----------------------------------//
      double ratio_2 = 0;
      int label_temp = 0;
      double t_temp = B[1*SNT+Queue[i]+label_temp];
      while((t_temp<=t_temp1)&(label_temp<NT[i])){
        for(int k=0; k<NY; ++k){
          double Y_n = y[Queue[i]+label_temp+k*SNT];
          double Y_star = y[Queue[i]+label_temp+k*SNT];
          for (int p = 0; p < NP; ++p){
            for(int m =0; m<M;++m){
              bB(m,0) = b[m*NY*NP+k*NP+p]*B[p*SNT+Queue[i]+label_temp];
            }
            Y_n -= gb[(k*NP+p)*N+i]*B[p*SNT+Queue[i]+label_temp];
            Y_star -= f_mmult(gi_star,bB)(0,0);
          }
          ratio_2 += (pow(Y_n,2) - pow(Y_star,2))/(2 * psi_eps[k]);
        }

        label_temp += 1;
        t_temp = B[1*SNT+Queue[i]+label_temp];
      }
      //------------------------------ ratio 3-----------------------------------//
      NumericMatrix b1(M,1);
      NumericVector u1(NP);
      NumericVector u1_star(NP);
      double ratio_3 = 0;

      for (int p = 0; p < NP; ++p){
        u1[p] = cgb[i+p*N];
      }

      for (int p = 0; p < NP; ++p){
        for (int k=0; k<NY; ++k){
          for (int m = 0; m < M; ++m){
            b1(m,0) = b[m*NY*NP+k*NP+p];
          }
          u1_star[p] += c[k]*f_mmult(gi_star,b1)(0,0);
        }
        ratio_3 += DELTA[i] * B_tdelta[loop1*2+p]  * (u1_star[p] - u1[p]);  
      }
      
      //------------------------------ ratio 4-----------------------------------//
      for(int k=0; k<NZ; ++k){
        z1(k,0) = z[k*N+i];
      }
      double ratio_4 = exp(f_mmult(beta1,z1)(0,0)) *(f_integral(u1, J, lambda, Fail_label_tdelta(0,loop1*delta_length+loop2), K, t_temp1, 1, 0, Fail_label_tdelta(0,loop1*delta_length+loop2), NP, IF_QUADRATIC, kns) - f_integral(u1_star, J, lambda, Fail_label_tdelta(0,loop1*delta_length+loop2), K, t_temp1, 1, 0, Fail_label_tdelta(0,loop1*delta_length+loop2), NP, IF_QUADRATIC, kns));
      //------------------------------ ratio 5-----------------------------------//
      
      double ratio_5 = 0;
      for (int m = 0; m < M; ++m){
        ratio_5 += (delta[m]-1)*(log(g[m*N+i]) - log(g_star[m]));
      }
      
      //----------------------------- judge -----------------------------------//
      double log_ratio = ratio_1 + ratio_2 + ratio_3 + ratio_4 + ratio_5;
      // double log_ratio = ratio_1 + ratio_2 + ratio_3 + ratio_4;
      double ratio_gi = exp(log_ratio);
      double randnum = runif(1)[0];
      if(randnum<ratio_gi){
        for(int m = 0; m<M; ++m){
          g_out[m*N+i] = g_star[m];
        }
        at_g[i] += 1;
      }
    }
  }
  
  return List::create(Rcpp::Named("g") = g_out,
                      Rcpp::Named("at_g") = at_g
  );
}
#endif
