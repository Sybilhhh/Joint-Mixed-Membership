#ifndef _F_PRE_H
#define _F_PRE_H

#include "f_mmult.h" 
#include "f_integral.h"
//#include "f_pregi.h"

#include <Rcpp.h> 
using namespace Rcpp;

// [[Rcpp::export]]
List f_pre(NumericMatrix cgb_test, NumericVector y, NumericVector B, NumericVector psi_eps, NumericVector OT, NumericVector DELTA, NumericVector Fail_label, NumericVector J, NumericVector lambda, NumericVector beta, NumericVector z, NumericVector Queue, NumericVector c, NumericVector NT, int N, int M, int NY, int K, int NZ, int SNT, int NP, int IF_QUADRATIC, NumericVector kns, NumericVector OT_label, NumericMatrix Fail_label_tdelta, NumericVector B_tdelta, NumericVector t_test, NumericVector delta, NumericMatrix at_g_test, NumericMatrix all_g_test){
  NumericMatrix beta1(1,NZ);
  for(int i=0; i<NZ; ++i){
    beta1(0,i) = beta[i];
  }
  
  const int t_length = t_test.size();
  const int delta_length = delta.size();
  NumericVector AUC(t_length*delta_length);
  
  NumericMatrix pi_test(t_length*delta_length,N);
  NumericMatrix denominator_pair(t_length*delta_length,4);
  NumericMatrix numerator_pair(t_length*delta_length,4);
  
  NumericVector numerator_pair_vec(t_length*delta_length*4);
  NumericVector denominator_pair_vec(t_length*delta_length*4);
  NumericVector pi_test_vec(t_length*delta_length*N);
  //NumericVector ratio_u_vec(t_length*delta_length*N);
  //NumericVector at_g_test_vec(t_length*delta_length*N);
  //NumericVector all_g_test_vec(t_length*delta_length*N*M);

    for(int loop1=0; loop1<t_length; ++loop1){
      for(int loop2=0; loop2<delta_length; ++loop2){
        double t_temp1 = t_test[loop1];
        double delta_temp1 = delta[loop2];

        NumericMatrix z1(NZ,1);
        for(int i=0; i<N; ++i){
          if(!((OT[i]<=t_temp1)&(DELTA[i]==1))){
            for(int k=0; k<NZ; ++k){
              z1(k,0) = z[k*N+i];
            }

            NumericVector u1(NP);
            for (int p = 0; p < NP; ++p){
              u1[p] = cgb_test(loop1*delta_length+loop2,i+p*N);
            }
            pi_test(loop1*delta_length+loop2,i) = exp( exp(f_mmult(beta1,z1)(0,0)) *(f_integral(u1, J, lambda, Fail_label_tdelta(0,loop1*delta_length+loop2), K, t_temp1, 1, 0, Fail_label_tdelta(0,loop1*delta_length+loop2), NP, IF_QUADRATIC, kns) - f_integral(u1, J, lambda, Fail_label_tdelta(1,loop1*delta_length+loop2), K, t_temp1+delta_temp1, 1, 0, Fail_label_tdelta(1,loop1*delta_length+loop2), NP, IF_QUADRATIC, kns) ));
          }
        }

        // calculate AUC value
        for(int l1=0; l1<N; ++l1){
          for(int l2=0; l2<N; ++l2){
            if(l1!=l2){

              // four senarios for the pairs (l1,l2)
              if((OT[l1]>t_temp1)&(OT[l1]<=(t_temp1+delta_temp1))&(DELTA[l1]==1)&(OT[l2]>(t_temp1+delta_temp1))){
                denominator_pair(loop1*delta_length+loop2,0) += 1;
                if(pi_test(loop1*delta_length+loop2,l1)<pi_test(loop1*delta_length+loop2,l2)){
                  numerator_pair(loop1*delta_length+loop2,0) += 1;
                }


              }else if((OT[l1]>t_temp1)&(OT[l1]<=(t_temp1+delta_temp1))&(DELTA[l1]==0)&(OT[l2]>(t_temp1+delta_temp1))){

                denominator_pair(loop1*delta_length+loop2,1) += 1-pi_test(loop1*delta_length+loop2,l1);
                if(pi_test(loop1*delta_length+loop2,l1)<pi_test(loop1*delta_length+loop2,l2)){
                  numerator_pair(loop1*delta_length+loop2,1) += 1-pi_test(loop1*delta_length+loop2,l1);
                }

              }else if((OT[l1]>t_temp1)&(OT[l1]<=(t_temp1+delta_temp1))&(DELTA[l1]==1)&(OT[l2]<=(t_temp1+delta_temp1))&(DELTA[l2]==0)&(OT[l1]<OT[l2])){

                denominator_pair(loop1*delta_length+loop2,2) += pi_test(loop1*delta_length+loop2,l2);
                if(pi_test(loop1*delta_length+loop2,l1)<pi_test(loop1*delta_length+loop2,l2)){
                  numerator_pair(loop1*delta_length+loop2,2) += pi_test(loop1*delta_length+loop2,l2);
                }

              }else if((OT[l1]>t_temp1)&(OT[l1]<=(t_temp1+delta_temp1))&(DELTA[l1]==0)&(OT[l2]<=(t_temp1+delta_temp1))&(DELTA[l2]==0)&(OT[l1]<OT[l2])){

                denominator_pair(loop1*delta_length+loop2,3) += (1-pi_test(loop1*delta_length+loop2,l1))*pi_test(loop1*delta_length+loop2,l2);
                if(pi_test(loop1*delta_length+loop2,l1)<pi_test(loop1*delta_length+loop2,l2)){
                  numerator_pair(loop1*delta_length+loop2,3) += (1-pi_test(loop1*delta_length+loop2,l1))*pi_test(loop1*delta_length+loop2,l2);
                }
              }
            }
          }
        }

        // for(int k=0; k<4; ++k){
        //   if(denominator_pair(i*delta_length+j,k)!=0){
        //     AUC(i*delta_length+j) += numerator_pair(i*delta_length+j,k)/(denominator_pair(i*delta_length+j,k)*S_MCMC);
        //   }
        // }

        AUC[loop1*delta_length+loop2] = (sum(numerator_pair(loop1*delta_length+loop2,_))/sum(denominator_pair(loop1*delta_length+loop2,_)) );
      }
    }

  
  
  for(int i=0; i<t_length; ++i){
    for(int j=0; j<delta_length; ++j){
      pi_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)] = pi_test(i*delta_length+j,_);
      numerator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)] = numerator_pair(i*delta_length+j,_);
      denominator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)] = denominator_pair(i*delta_length+j,_);
      /*at_g_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)] = at_g_test(i*delta_length+j,_);
      all_g_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)] = all_g_test(i*delta_length+j,_);*/
      
    }
  }
  
  
  return List::create(Rcpp::Named("numerator_vec") = numerator_pair_vec,
                      Rcpp::Named("denominator_vec") = denominator_pair_vec,
                      Rcpp::Named("AUC") = AUC,
                      Rcpp::Named("pi_test_vec") = pi_test_vec
                      /*,Rcpp::Named("at_g_test_vec") = at_g_test_vec,
                      Rcpp::Named("all_g_test_vec") = all_g_test_vec*/
  );
}
#endif
