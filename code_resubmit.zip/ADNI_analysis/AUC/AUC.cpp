#include <RcppArmadillo.h>

#include "f_mmult.h"
#include "f_gb.h"
#include "f_pregi.h"
#include "f_cgb.h"
#include "f_pre.h"

using namespace Rcpp;

// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
List AUC(List test_data, List para, List mh, List prior, int K, int iter, int rep, int T, int S, double pi, int IF_QUADRATIC){

  // Cox
  double alpha1 = prior[0];
  double alpha2 = prior[1];
  NumericVector beta0 = prior[2];
  NumericMatrix Sigma_beta0 = prior[3];
  double c0 = prior[4];
  double sigma_c0 = prior[5];
  // MMM
  NumericVector b0 = prior[6];
  NumericMatrix Sigma_b0 = prior[7];
  double a0_delta = prior[8];
  double b0_delta = prior[9];
  double d0 = prior[10];
  double alpha_eps0 = prior[11];
  double beta_eps0 = prior[12];
  

  double c_beta = mh[0];
  double c_c = mh[1];
  double c_delta = mh[2];
  double c_b = mh[3];
  double c_g = mh[4];
  
  NumericVector lambda = para[0];
  NumericVector beta = para[1];
  NumericVector c = para[2];
  NumericVector b = para[3];
  NumericVector g = para[4];
  NumericVector psi_eps = para[5];
  double delta_0 = para[6];
  NumericVector xi = para[7];
  
  NumericVector OT_label = test_data[0];
  NumericVector B = test_data[1];
  NumericVector J =test_data[2];
  NumericVector Fail_label = test_data[3];
  NumericVector z = test_data[4];
  NumericVector OT = test_data[5];
  NumericVector DELTA = test_data[6];
  NumericVector Queue = test_data[7];
  NumericVector y = test_data[8];
  NumericVector NT = test_data[9];
  NumericVector kns = test_data[10];
  NumericMatrix Fail_label_tdelta = test_data[11];
  NumericVector t_test = test_data[12];
  NumericVector delta_test = test_data[13];
  NumericVector B_tdelta = test_data[14];
  
  // MMM
  int M = xi.size();
  int NY = psi_eps.size();
  int NP = b.size()/(M*NY);
  // Cox
  int SNT = B.size()/NP;
  int N = g.size()/M;
  int NZ = beta.size();
  int J_len = J.size();

  int t_length = t_test.size();
  int delta_length = delta_test.size();

  NumericVector gb(N*NY*NP);
  NumericVector cgb(N*NP);
  NumericMatrix cgb_test(t_length*delta_length,N*NP);

  NumericMatrix numerator_pair(t_length*delta_length,4);
  NumericMatrix denominator_pair(t_length*delta_length,4);
  NumericVector numerator_pair_vec(t_length*delta_length*4);
  NumericVector denominator_pair_vec(t_length*delta_length*4);
  NumericMatrix pi_test(t_length*delta_length,N);
  NumericVector pi_test_vec(t_length*delta_length*N);
  NumericMatrix AUC(S,t_length*delta_length);
  NumericVector AUC_vec(t_length*delta_length);

  NumericMatrix at_g_test(t_length*delta_length,N);
  NumericMatrix all_g_test(t_length*delta_length,N*M);
  NumericVector at_g_test_vec(t_length*delta_length*N);
  NumericVector all_g_test_vec(t_length*delta_length*N*M);

  NumericMatrix g_test_str(t_length*delta_length,T*N*M);
  NumericVector at_g(N);

  NumericVector g_str(T*N*M);
  
  gb = f_gb(b, g, N, M, NY, NP);
  cgb = f_cgb(c, gb, N, NY, NP);
  
  for(int t=0; t<T; ++t){
    /*if(t<(T-S-1)){
      List g_all = f_gi(cgb, delta_0, xi, gb, b, y, B, g, psi_eps, OT, DELTA, Fail_label, J, lambda, beta, z, Queue, c, NT, N, M, NY, K, NZ, SNT, d0, c_g, at_g,NP,IF_QUADRATIC,kns,OT_label);
      g = g_all[0];
      at_g = g_all[1];
      gb = f_gb(b, g, N, M, NY, NP);
      cgb = f_cgb(c, gb, N, NY, NP);
    }*/
    for(int loop1=0; loop1<t_length; ++loop1){
      for(int loop2=0; loop2<delta_length; ++loop2){
        NumericVector at_g = at_g_test(loop1*delta_length+loop2,_);
        NumericVector g = all_g_test(loop1*delta_length+loop2,_);
        gb = f_gb(b, g, N, M, NY, NP);
        cgb = f_cgb(c, gb, N, NY, NP);
        List g_all = f_pregi(cgb, delta_0, xi, gb, b, y, B, g, psi_eps, OT, DELTA, Fail_label, J, lambda, beta, z, Queue, c, NT, N, M, NY, K, NZ, SNT, d0, c_g, at_g, NP, IF_QUADRATIC, kns, OT_label, Fail_label_tdelta, t_test, delta_test, B_tdelta, loop1, loop2);
        g = g_all[0];
        at_g = g_all[1];
        all_g_test(loop1*delta_length+loop2,_) = g;
        at_g_test(loop1*delta_length+loop2,_) = at_g;
        gb = f_gb(b, g, N, M, NY, NP);
        cgb = f_cgb(c, gb, N, NY, NP);
        cgb_test(loop1*delta_length+loop2,_) = cgb;

        for(int i = 0; i<N*M; ++i){
          g_test_str[loop1*delta_length+loop2,t*N*M+i] = g[i];
        }
      }
    }

    if(t>(T-S-1)){
      int ind = t-(T-S);
      List pre_all = f_pre(cgb_test, y, B, psi_eps, OT, DELTA, Fail_label, J, lambda, beta, z, Queue, c, NT, N, M, NY, K, NZ, SNT, NP, IF_QUADRATIC, kns, OT_label, Fail_label_tdelta, B_tdelta, t_test, delta_test, at_g_test, all_g_test);
      numerator_pair_vec = pre_all[0];
      denominator_pair_vec = pre_all[1];
      AUC_vec = pre_all[2];
      pi_test_vec = pre_all[3];

      for(int i=0; i<t_length; ++i){
        for(int j=0; j<delta_length; ++j){
          pi_test(i*delta_length+j,_) = pi_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)];
          numerator_pair(i*delta_length+j,_) = numerator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)];
          denominator_pair(i*delta_length+j,_) = denominator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)];
        }
      }
      AUC(ind,_) = AUC_vec;
      /*
      List pre_all = f_pre(cgb, gb, b, y, B, g, psi_eps, OT, DELTA, Fail_label, J, lambda, beta, z, Queue, c, NT, N, M, NY, K, NZ, SNT, NP, IF_QUADRATIC, kns, OT_label, Fail_label_tdelta, t_test, delta_test);
      numerator_pair_vec = pre_all[0];
      denominator_pair_vec = pre_all[1];
      AUC_vec = pre_all[2];
      pi_test_vec = pre_all[3];

      for(int i=0; i<t_length; ++i){
        for(int j=0; j<delta_length; ++j){
          pi_test(i*delta_length+j,_) = pi_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)];
          numerator_pair(i*delta_length+j,_) = numerator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)];
          denominator_pair(i*delta_length+j,_) = denominator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)];
        }
      }
      AUC(ind,_) = AUC_vec;*/
      /*
      List pre_all = f_pre(cgb, delta_0, xi, gb, b, y, B, g, psi_eps, OT, DELTA, Fail_label, J, lambda, beta, z, Queue, c, NT, N, M, NY, K, NZ, SNT, d0, c_g, at_g, NP, IF_QUADRATIC, kns, OT_label, Fail_label_tdelta, B_tdelta, t_test, delta_test, at_g_test, all_g_test);
      numerator_pair_vec = pre_all[0];
      denominator_pair_vec = pre_all[1];
      AUC_vec = pre_all[2];
      pi_test_vec = pre_all[3];
      all_g_test_vec = pre_all[4];
      at_g_test_vec = pre_all[5];

      for(int i=0; i<t_length; ++i){
        for(int j=0; j<delta_length; ++j){
          pi_test(i*delta_length+j,_) = pi_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)];
          numerator_pair(i*delta_length+j,_) = numerator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)];
          denominator_pair(i*delta_length+j,_) = denominator_pair_vec[Range((i*delta_length+j)*4,(i*delta_length+j+1)*4-1)];

          at_g_test(i*delta_length+j,_) = at_g_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)];
          all_g_test(i*delta_length+j,_) = all_g_test_vec[Range((i*delta_length+j)*N,(i*delta_length+j+1)*N-1)];
        }
      }
      AUC(ind,_) = AUC_vec;
      for(int loop1=0; loop1<t_length; ++loop1){
        for(int loop2=0; loop2<delta_length; ++loop2){
          for(int i = 0; i<N*M; ++i){
            g_test_str[loop1*delta_length+loop2,t*N*M+i] = all_g_test(loop1*delta_length+loop2,i);
          }
        }
      }*/
    }
  
    if((t+1)%100==0){
      Rprintf("\rRunning MCMC, %d/%d replication, %f%% completed...",iter,rep,(t+1)*100.0/T);
    }
    
  }
  
  return List::create(Rcpp::Named("at_g") = at_g,
                      Rcpp::Named("g_str") = g_str
                      , Rcpp::Named("gb") = gb
                      , Rcpp::Named("cgb") = cgb
                      , Rcpp::Named("AUC") = AUC
                      , Rcpp::Named("pi_test") = pi_test
                      , Rcpp::Named("at_g_test") = at_g_test
                      , Rcpp::Named("all_g_test") = all_g_test
                      , Rcpp::Named("g_test_str") = g_test_str
                      );
}