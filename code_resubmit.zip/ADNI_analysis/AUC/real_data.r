library("mvtnorm")
library("numDeriv")
library("Rcpp")
library("RcppArmadillo")
library("RcppEigen")
library("LaplacesDemon")

sourceCpp("AUC.cpp")

test_data = readRDS("test_data.RData")
N = 200
M = 3 # number of extreme profile
NY= 2 # dimension of y
NZ= 5 # number of covariates
NP = 6
J_len = 11
M_mcmc = 3
K = 10
####################################### Simulation setting and control ###################################################
REP= 5    ## number of replication
TT=10000    ## number of iteration of mcmc
S= 5000  ## T-S is the number of burn-in iteration
IF_QUADRATIC = 0
#----------------- Save data ----------------------#
#---------- Mixed Membership model---------------#
'g_mcmc = array(0,dim=c(REP,TT,N,M))
g_rep = array(0,dim = c(REP,N,M))'

result_AUC = matrix(0,REP,2*3)

c_beta = 5.5
c_c = 0.2
c_delta = 0.08
c_b = 10
c_g = 0.05

mh = list()
mh[[1]] = c_beta
mh[[2]] = c_c
mh[[3]] = c_delta
mh[[4]] = c_b
mh[[5]] = c_g

b_rep <- read.csv("b_rep.txt", row.names=1, sep="")
psi_epsrep <- read.csv("psi_epsrep.txt", row.names=1, sep="")
xi_rep <- read.csv("xi_rep.txt", row.names=1, sep="")
delta_0_rep <- read.csv("delta_0_rep.txt", row.names=1, sep="")
c_rep <- read.csv("c_rep.txt", row.names=1, sep="")
beta_rep <- read.csv("beta_rep.txt", row.names=1, sep="")
lambda_rep <- read.csv("lambda_rep.txt", row.names=1, sep="")

#######################################################################################################################
# MCMC
start_time = Sys.time()
for(iter in 1:REP){
  num_list = 15
  ####### initial value #######
  #---------- Cox --------------------#
  lambda_cpp = as.vector(unlist(lambda_rep[iter,]))
  c_cpp = as.vector(unlist(c_rep[iter,]))
  beta_cpp = as.vector(unlist(beta_rep[iter,]))
  
  # --------------- MMM ---------------#
  b_cpp = as.vector(unlist(b_rep[iter,,]))
  psi_epscpp = as.vector(unlist(psi_epsrep[iter,]))
  delta_0_cpp = as.vector(unlist(delta_0_rep$x[iter]))
  xi_cpp = as.vector(unlist(xi_rep[iter,]))
  g_cpp = as.numeric(rdirichlet(N,delta_0_cpp*xi_cpp))
  
  '####### iteration value #######
  #---------- Cox --------------------#
  lambda_str = as.vector(unlist(lambda_mcmc[iter,,]))
  c_str = as.vector(unlist(c_mcmc[iter,,]))
  beta_str = as.vector(unlist(beta_mcmc[iter,,]))
  
  # --------------- MMM ---------------#
  b_str = as.vector(unlist(b_mcmc[iter,,,]))
  psi_epsstr = as.vector(unlist(psi_epsmcmc[iter,,]))
  delta_0_str = as.vector(unlist(delta_0_mcmc[iter,]))
  xi_str = as.vector(unlist(xi_mcmc[iter,,]))
  g_str = result$g_str'
  
  ####### prior distribution ########
  #---------- Cox --------------------#
  # lambda
  alpha1 = 2
  alpha2 = 0.01
  # beta
  beta0 = rep(0,NZ)
  Sigma_beta0 = diag(NZ)
  # c
  c0 = 0
  sigma_c0 = 1
  # --------------- MMM ---------------#
  # b
  b0 = rep(0,NP)
  Sigma_b0 = diag(NP)*100
  # delta
  a0_delta = 1.2
  b0_delta = 5
  # g
  d0 = 1
  # psi_eps
  alpha_eps0 = 9
  beta_eps0 = 4
  
  prior = list()
  # Cox
  prior[[1]] = alpha1
  prior[[2]] = alpha2
  prior[[3]] = beta0
  prior[[4]] = Sigma_beta0
  prior[[5]] = c0
  prior[[6]] = sigma_c0
  # MMM
  prior[[7]] = b0
  prior[[8]] = Sigma_b0
  prior[[9]] = a0_delta
  prior[[10]] = b0_delta
  prior[[11]] = d0
  prior[[12]] = alpha_eps0
  prior[[13]] = beta_eps0
  
  
  para = list()
  # Cox
  para[[1]] = lambda_cpp
  para[[2]] = beta_cpp
  para[[3]] = c_cpp
  # MMM
  para[[4]] = b_cpp
  para[[5]] = g_cpp
  para[[6]] = psi_epscpp
  para[[7]] = delta_0_cpp
  para[[8]] = xi_cpp
  
  'para_str = list()
  # Cox
  para_str[[1]] = lambda_str
  para_str[[2]] = beta_str
  para_str[[3]] = c_str
  # MMM
  para_str[[4]] = b_str
  para_str[[5]] = psi_epsstr
  para_str[[6]] = delta_0_str
  para_str[[7]] = xi_str
  para_str[[8]] = g_str'
  
  
  result = AUC(test_data[((iter-1)*num_list+1):((iter-1)*num_list+15)], para, mh, prior, K, iter, REP, TT, S, pi,IF_QUADRATIC)
  if(iter == 1){
    save.image(file = "2K3M_NP61.RData")
  }
  if(iter == 2){
    save.image(file = "2K3M_NP62.RData")
  }
  if(iter == 3){
    save.image(file = "2K3M_NP63.RData")
  }
  if(iter == 4){
    save.image(file = "2K3M_NP64.RData")
  }
  if(iter == 5){
    save.image(file = "2K3M_NP65.RData")
  }
  
  'for(i in 1:TT){
    g_mcmc[iter,i,,] = matrix(result$g_str[((i-1)*N*M+1):(i*N*M)],nrow=N,byrow=F)
  }
  
  # Cox
  g_rep[iter,,] = apply(g_mcmc[iter,S:TT,,],2:3,mean)'
  
  apply(result$AUC,2,mean)
  result_AUC[iter,] = apply(result$AUC,2,mean)
}

Iter_time = Sys.time() - start_time
sprintf("Need %.3f mins to iter %d replication", Iter_time, REP)

result_AUC
'hist(result$pi_test)
hist(result$AUC[,1])
hist(result$AUC[,2])
hist(result$AUC[,3])
hist(result$AUC[,4])
hist(result$AUC[,5])'

mean(result$at_g_test[1,]/TT)
mean(result$at_g_test[2,]/TT)
mean(result$at_g_test[3,]/TT)
mean(result$at_g_test[4,]/TT)
mean(result$at_g_test[5,]/TT)
mean(result$at_g_test[6,]/TT)

write.table(result_AUC,"AUC.txt")

save.image(file = "2K3M_NP6.RData")
